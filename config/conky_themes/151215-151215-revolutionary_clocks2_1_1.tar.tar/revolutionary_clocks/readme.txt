Revolutionary clocks comes in 4 sizes
HD, midi, mini & supermini

It is distinguished from other such clocks by the clock rings not having a fixed starting position but rather move as a function of time and likewise expand circumferentially as a function of time. 

It is configurable and has vast potential if a graphics designer used their imagination. I have quickly uploaded it to demonstrate the scripts potential.

The lua script is explained in the c_c_s_explanation.txt file.

To install just move or copy the " .Conky " hidden folder to your user/home folder!

Don't forget to install the fonts!

to run, execute ' start_conky.sh '

To enable conky to start with the system go to " startup applications " and add in the " command " the file " .Conky/revolutionary_clock/...x.../start_conky.sh " where ...x... signifies the desired conky size e.g. rev_hd.

  

