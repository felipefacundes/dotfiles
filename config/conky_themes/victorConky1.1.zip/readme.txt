

This conky has three sizes for your usage and two type for arch linux distributation and other linux distributations

https://drive.google.com/open?id=17opw7z9EJSsnAujZCg9txJSI3bnxW1jp

The widgets in this package are:
archSmall
archMedium
archLarge
linuxSmall
linuxMedium
linuxLarg

https://drive.google.com/open?id=1S_uGgAQemgEZXbJQTlUXiQu6GOUJxQ6O
https://drive.google.com/open?id=1qPyCfn3hOCgAGx8t5a-dTYcjeZTNutcI

To use the widget set below, you can use two methods to install:
1. Install with installer script (tested on gnome)
2. Manual confinement (recomended)
I propose the second method (manual configurations)
Note: First of all, make sure the conky-manager is installed
The first method:
Run the installer script

The second method:
1.Download the whole repository and Install fonts inside the fonts folder

Copy the victorConky folder to this path
~/.conky 

now you can choos your favorite conky from conky-manager software

https://drive.google.com/open?id=1pbYi6IGTRwqyHFWsDnIe7JprXQM1S0xd
