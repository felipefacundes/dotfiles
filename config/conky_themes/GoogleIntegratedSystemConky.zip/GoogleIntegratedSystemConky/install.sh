#!/bin/bash
mv fonts/ ~/.local/share/ ;
sudo mv plank/gisc /usr/share/plank/themes/
cd ..
mv GoogleIntegratedSystemConky/ ~/.config
