#!/bin/bash

sleep 20 && conky -c ~/.config/conky/conky.conf
